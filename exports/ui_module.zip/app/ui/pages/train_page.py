import customtkinter as ctk

class TrainPage(ctk.CTkFrame):

    def __init__(self, master):
        super().__init__(master)

        ctk.CTkLabel(
            self,
            text="🧠 Train Model",
            font=("Segoe UI",28,"bold")
        ).pack(pady=30)