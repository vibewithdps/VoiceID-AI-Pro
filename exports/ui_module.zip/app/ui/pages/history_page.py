import customtkinter as ctk

class HistoryPage(ctk.CTkFrame):

    def __init__(self, master):
        super().__init__(master)

        ctk.CTkLabel(
            self,
            text="📜 History",
            font=("Segoe UI",28,"bold")
        ).pack(pady=30)