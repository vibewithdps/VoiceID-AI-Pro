from app.auth.password import hash_password, verify_password
from app.auth.validators import (
    validate_login_data,
    validate_registration_data,
    validate_reset_password_data,
)
from app.database.database import Database


class AuthManager:

    def __init__(self):

        self.db = Database()

    # ======================================================
    # Register New User
    # ======================================================

    def register(
        self,
        full_name,
        username,
        email,
        password,
        confirm_password
    ):

        is_valid, message = validate_registration_data(
            full_name,
            username,
            email,
            password,
            confirm_password,
        )

        if not is_valid:
            return False, message

        full_name = full_name.strip()
        username = username.strip()
        email = email.strip().lower()

        # -----------------------------
        # Check existing username/email
        # -----------------------------

        user = self.db.execute(
            """
            SELECT id
            FROM users
            WHERE username = ?
               OR email = ?
            """,
            (username, email)
        ).fetchone()

        if user:
            return False, "Username or Email already exists."

        # -----------------------------
        # Hash Password
        # -----------------------------

        hashed_password = hash_password(password)

        # -----------------------------
        # Insert User
        # -----------------------------

        self.db.execute(
            """
            INSERT INTO users
            (
                full_name,
                username,
                email,
                password
            )
            VALUES
            (
                ?, ?, ?, ?
            )
            """,
            (
                full_name,
                username,
                email,
                hashed_password
            )
        )

        return True, "Account created successfully."

    # ======================================================
    # Login
    # ======================================================

    def login(
        self,
        email,
        password
    ):

        is_valid, message = validate_login_data(email, password)

        if not is_valid:
            return False, message

        email = email.strip().lower()

        user = self.db.execute(
            """
            SELECT
                id,
                full_name,
                username,
                email,
                password
            FROM users
            WHERE email = ?
            """,
            (email,)
        ).fetchone()

        if user is None:
            return False, "Invalid email or password."

        stored_password = user[4]

        if not verify_password(password, stored_password):
            return False, "Invalid email or password."

        return True, user

    # ======================================================
    # Reset Password
    # ======================================================

    def reset_password(self, email, new_password, confirm_password):

        is_valid, message = validate_reset_password_data(
            email,
            new_password,
            confirm_password,
        )

        if not is_valid:
            return False, message

        email = email.strip().lower()

        user = self.db.execute(
            """
            SELECT id
            FROM users
            WHERE email = ?
            """,
            (email,)
        ).fetchone()

        if user is None:
            return False, "No account found for that email."

        hashed_password = hash_password(new_password)

        self.db.execute(
            """
            UPDATE users
            SET password = ?
            WHERE email = ?
            """,
            (hashed_password, email)
        )

        return True, "Password updated successfully."

    # ======================================================
    # Get All Users
    # ======================================================

    def get_all_users(self):

        return self.db.execute(
            """
            SELECT
                id,
                full_name,
                username,
                email,
                created_at
            FROM users
            ORDER BY full_name
            """
        ).fetchall()

    def get_user_choices(self):

        users = self.get_all_users()
        choices = []

        for user in users:
            choices.append(user[1] or user[2] or user[3])

        return choices